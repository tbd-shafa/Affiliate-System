-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 22, 2025 at 05:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Affiliate_System`
--

-- --------------------------------------------------------

--
-- Table structure for table `affiliate_referrals`
--

CREATE TABLE `affiliate_referrals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `referrer_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `affiliate_referrals`
--

INSERT INTO `affiliate_referrals` (`id`, `referrer_id`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 2, 10, '2024-12-27 06:23:20', '2024-12-27 06:23:20'),
(2, 2, 11, '2024-12-27 06:24:10', '2024-12-27 06:24:10'),
(3, 2, 14, '2024-12-30 00:55:16', '2024-12-30 00:55:16'),
(4, 2, 18, '2024-12-30 01:01:32', '2024-12-30 01:01:32'),
(5, 2, 20, '2024-12-30 01:04:13', '2024-12-30 01:04:13'),
(6, 13, 21, '2024-12-30 03:23:09', '2024-12-30 03:23:09'),
(7, 13, 22, '2024-12-30 03:24:52', '2024-12-30 03:24:52'),
(8, 2, 23, '2024-12-30 03:26:15', '2024-12-30 03:26:15'),
(9, 2, 27, '2024-12-30 04:08:23', '2024-12-30 04:08:23'),
(10, 2, 29, '2024-12-30 04:21:47', '2024-12-30 04:21:47'),
(11, 13, 31, '2024-12-30 04:26:51', '2024-12-30 04:26:51'),
(12, 13, 32, '2024-12-30 04:28:24', '2024-12-30 04:28:24'),
(13, 13, 35, '2024-12-30 04:38:10', '2024-12-30 04:38:10'),
(14, 13, 38, '2024-12-30 04:44:41', '2024-12-30 04:44:41'),
(15, 2, 39, '2024-12-30 04:46:19', '2024-12-30 04:46:19'),
(16, 2, 40, '2024-12-31 00:43:16', '2024-12-31 00:43:16'),
(17, 2, 44, '2024-12-31 22:48:42', '2024-12-31 22:48:42'),
(18, 2, 46, '2025-01-01 00:33:26', '2025-01-01 00:33:26'),
(19, 47, 49, '2025-01-02 00:22:09', '2025-01-02 00:22:09'),
(20, 2, 50, '2025-01-02 00:24:03', '2025-01-02 00:24:03'),
(21, 2, 51, '2025-01-02 02:55:56', '2025-01-02 02:55:56'),
(22, 2, 53, '2025-01-02 02:57:48', '2025-01-02 02:57:48'),
(23, 53, 54, '2025-01-02 03:12:12', '2025-01-02 03:12:12'),
(24, 2, 56, '2025-01-02 06:29:05', '2025-01-02 06:29:05'),
(25, 55, 57, '2025-01-03 06:13:51', '2025-01-03 06:13:51'),
(26, 2, 62, '2025-01-06 04:18:20', '2025-01-06 04:18:20'),
(27, 55, 64, '2025-01-06 04:37:11', '2025-01-06 04:37:11'),
(28, 2, 65, '2025-01-06 04:40:47', '2025-01-06 04:40:47');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `commissions`
--

CREATE TABLE `commissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `affiliate_user_id` int(11) NOT NULL,
  `subscriptions_id` int(11) NOT NULL,
  `package_amount` decimal(10,2) NOT NULL,
  `earn_amount` decimal(10,2) NOT NULL,
  `package_id` int(11) NOT NULL,
  `percentage` decimal(5,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `commissions`
--

INSERT INTO `commissions` (`id`, `user_id`, `affiliate_user_id`, `subscriptions_id`, `package_amount`, `earn_amount`, `package_id`, `percentage`, `created_at`, `updated_at`) VALUES
(1, 10, 2, 9, 2000.00, 300.00, 2, 15.00, '2024-12-27 07:15:29', '2024-12-27 07:15:29'),
(2, 11, 2, 10, 2500.00, 375.00, 3, 15.00, '2024-12-27 07:16:38', '2024-12-27 07:16:38'),
(3, 10, 2, 12, 2500.00, 500.00, 3, 20.00, '2024-12-31 00:40:10', '2024-12-31 00:40:10'),
(4, 40, 2, 13, 2000.00, 400.00, 2, 20.00, '2024-12-31 00:45:04', '2024-12-31 00:45:04'),
(5, 44, 2, 14, 1500.00, 300.00, 1, 20.00, '2024-12-31 23:41:52', '2024-12-31 23:41:52'),
(6, 44, 2, 15, 2500.00, 500.00, 3, 20.00, '2024-12-31 23:51:27', '2024-12-31 23:51:27'),
(7, 50, 2, 17, 1500.00, 300.00, 1, 20.00, '2025-01-02 00:24:35', '2025-01-02 00:24:35'),
(8, 53, 2, 18, 2000.00, 400.00, 2, 20.00, '2025-01-02 02:58:33', '2025-01-02 02:58:33'),
(9, 54, 53, 19, 1500.00, 150.00, 1, 10.00, '2025-01-02 03:12:31', '2025-01-02 03:12:31'),
(11, 57, 55, 21, 1500.00, 150.00, 1, 10.00, '2025-01-03 06:15:23', '2025-01-03 06:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2024_12_23_105421_create_subscriptions_table', 1),
(5, '2024_12_23_105834_create_commissions_table', 1),
(6, '2024_12_24_070141_create_affiliate_referrals_table', 1),
(7, '2024_12_24_093508_create_subscription_plans_table', 1),
(8, '2024_12_25_115610_create_roles_table', 1),
(9, '2024_12_25_115658_create_role_user_table', 1),
(10, '2024_12_26_090632_create_user_details_table', 1),
(11, '2025_01_03_061407_create_payouts_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payouts`
--

CREATE TABLE `payouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `affiliate_user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_by` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payouts`
--

INSERT INTO `payouts` (`id`, `affiliate_user_id`, `amount`, `payment_by`, `remarks`, `created_at`, `updated_at`) VALUES
(2, 2, 1.00, 'cash on delivery', 'test purpose 1', '2025-01-03 04:01:55', '2025-01-03 04:01:55'),
(3, 2, 1.00, 'cash on delivery', 'test purpose', '2025-01-03 04:02:50', '2025-01-03 04:02:50'),
(4, 2, 2.00, 'cash on delivery', 'test purpose 2', '2025-01-03 04:03:25', '2025-01-03 04:03:25'),
(5, 55, 1.50, 'cash on delivery', 'test purpose', '2025-01-03 06:19:40', '2025-01-03 06:19:40'),
(6, 55, 1.00, 'cash on delivery', 'test purpose', '2025-01-03 06:45:40', '2025-01-03 06:45:40'),
(9, 2, 1000.00, 'Cash', 'Partial payment by Cash', '2025-01-05 22:21:12', '2025-01-05 22:21:12'),
(10, 2, 2071.00, 'Bank', 'Full payment', '2025-01-05 22:24:46', '2025-01-05 22:24:46'),
(13, 55, 1.00, 'cash on delivery', 'test purpose', '2025-01-06 23:05:00', '2025-01-06 23:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2024-12-27 04:34:24', '2024-12-27 04:34:24'),
(2, 'affiliate_user', '2024-12-27 04:34:24', '2024-12-27 04:34:24'),
(3, 'user', '2024-12-27 04:34:24', '2024-12-27 04:34:24');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2025-01-01 23:56:22', '2025-01-01 23:56:22'),
(2, 2, 3, '2025-01-06 06:10:48', '2025-01-06 06:10:48'),
(13, 10, 3, '2024-12-27 06:23:20', '2024-12-27 06:23:20'),
(14, 11, 3, '2024-12-27 06:24:10', '2024-12-27 06:24:10'),
(16, 13, 3, '2024-12-29 23:58:38', '2024-12-30 00:23:34'),
(18, 14, 3, '2024-12-30 00:55:16', '2024-12-30 00:55:16'),
(19, 15, 2, '2025-01-02 01:28:26', '2025-01-02 01:28:26'),
(21, 17, 3, '2024-12-30 01:00:46', '2024-12-30 01:00:46'),
(22, 18, 3, '2024-12-30 01:01:32', '2024-12-30 01:01:32'),
(23, 19, 3, '2024-12-30 01:02:08', '2024-12-30 01:02:08'),
(24, 20, 3, '2024-12-30 01:04:13', '2024-12-30 01:04:13'),
(25, 21, 3, '2024-12-30 03:23:09', '2024-12-30 03:23:09'),
(26, 22, 3, '2024-12-30 03:24:52', '2024-12-30 03:24:52'),
(27, 23, 3, '2024-12-30 03:26:15', '2024-12-30 03:26:15'),
(29, 24, 3, '2024-12-30 03:51:19', '2024-12-30 03:51:19'),
(30, 25, 3, '2024-12-30 03:52:23', '2024-12-30 03:52:23'),
(31, 26, 3, '2024-12-30 04:06:39', '2024-12-30 04:06:39'),
(32, 27, 3, '2024-12-30 04:08:23', '2024-12-30 04:08:23'),
(33, 28, 3, '2024-12-30 04:11:55', '2024-12-30 04:11:55'),
(34, 29, 3, '2024-12-30 04:21:47', '2024-12-30 04:21:47'),
(35, 30, 3, '2024-12-30 04:22:51', '2024-12-30 04:22:51'),
(36, 31, 3, '2024-12-30 04:26:51', '2024-12-30 04:26:51'),
(37, 32, 3, '2024-12-30 04:28:24', '2024-12-30 04:28:24'),
(38, 33, 3, '2024-12-30 04:29:29', '2024-12-30 04:29:29'),
(39, 34, 3, '2024-12-30 04:30:55', '2024-12-30 04:30:55'),
(40, 35, 3, '2025-01-01 23:56:34', '2025-01-01 23:56:34'),
(41, 36, 3, '2024-12-30 04:40:11', '2024-12-30 04:40:11'),
(42, 37, 3, '2024-12-30 04:41:13', '2024-12-30 04:41:13'),
(43, 38, 3, '2024-12-30 04:44:41', '2024-12-30 04:44:41'),
(44, 39, 3, '2024-12-30 04:46:19', '2024-12-30 04:46:19'),
(45, 2, 2, '2025-01-06 06:10:48', '2025-01-06 06:10:48'),
(46, 40, 2, '2025-01-02 01:28:39', '2025-01-02 01:28:39'),
(49, 42, 3, '2024-12-31 03:24:37', '2024-12-31 03:24:37'),
(51, 42, 2, '2024-12-31 03:24:37', '2024-12-31 03:24:37'),
(53, 43, 2, '2025-01-01 23:27:24', '2025-01-01 23:27:24'),
(54, 43, 3, '2025-01-01 23:27:24', '2025-01-01 23:27:24'),
(55, 43, 1, '2025-01-01 23:27:24', '2025-01-01 23:27:24'),
(56, 44, 3, '2024-12-31 22:48:42', '2024-12-31 22:48:42'),
(57, 45, 3, '2024-12-31 22:50:01', '2024-12-31 22:50:01'),
(58, 46, 3, '2025-01-01 00:33:26', '2025-01-01 00:33:26'),
(59, 16, 3, '2025-01-01 23:29:45', '2025-01-01 23:29:45'),
(63, 48, 3, '2025-01-02 00:06:49', '2025-01-02 00:06:49'),
(64, 49, 3, '2025-01-02 03:28:35', '2025-01-02 03:28:35'),
(65, 50, 3, '2025-01-06 03:29:07', '2025-01-06 03:29:07'),
(69, 47, 3, '2025-01-02 01:00:03', '2025-01-02 01:00:03'),
(71, 15, 3, '2025-01-02 01:28:26', '2025-01-02 01:28:26'),
(72, 40, 3, '2025-01-02 01:28:39', '2025-01-02 01:28:39'),
(74, 51, 3, '2025-01-02 02:55:56', '2025-01-02 02:55:56'),
(75, 52, 3, '2025-01-02 02:57:02', '2025-01-02 02:57:02'),
(76, 53, 3, '2025-01-06 04:45:41', '2025-01-06 04:45:41'),
(77, 53, 2, '2025-01-06 04:45:41', '2025-01-06 04:45:41'),
(78, 54, 3, '2025-01-06 04:46:02', '2025-01-06 04:46:02'),
(81, 56, 3, '2025-01-02 06:29:05', '2025-01-02 06:29:05'),
(83, 57, 3, '2025-01-03 06:13:51', '2025-01-03 06:13:51'),
(85, 55, 3, '2025-01-06 23:07:20', '2025-01-06 23:07:20'),
(86, 55, 2, '2025-01-06 23:07:20', '2025-01-06 23:07:20'),
(89, 59, 2, '2025-01-06 02:09:13', '2025-01-06 02:09:13'),
(90, 59, 3, '2025-01-06 02:09:13', '2025-01-06 02:09:13'),
(91, 50, 2, '2025-01-06 03:29:07', '2025-01-06 03:29:07'),
(94, 61, 2, '2025-01-06 04:06:57', '2025-01-06 04:06:57'),
(95, 62, 3, '2025-01-06 04:18:20', '2025-01-06 04:18:20'),
(96, 63, 3, '2025-01-06 04:21:20', '2025-01-06 04:21:20'),
(97, 64, 3, '2025-01-06 04:37:11', '2025-01-06 04:37:11'),
(98, 65, 3, '2025-01-06 23:06:51', '2025-01-06 23:06:51'),
(99, 66, 3, '2025-01-06 05:22:39', '2025-01-06 05:22:39'),
(100, 67, 1, '2025-01-06 05:23:52', '2025-01-06 05:23:52'),
(103, 65, 2, '2025-01-06 23:06:51', '2025-01-06 23:06:51'),
(104, 68, 3, '2025-01-06 06:02:03', '2025-01-06 06:02:03'),
(105, 68, 2, '2025-01-06 06:02:03', '2025-01-06 06:02:03'),
(106, 69, 3, '2025-01-06 06:13:48', '2025-01-06 06:13:48'),
(107, 70, 1, '2025-01-06 06:14:39', '2025-01-06 06:14:39'),
(109, 71, 1, '2025-01-06 06:16:18', '2025-01-06 06:16:18'),
(110, 71, 3, '2025-01-06 06:16:18', '2025-01-06 06:16:18'),
(111, 71, 2, '2025-01-06 06:16:18', '2025-01-06 06:16:18'),
(112, 72, 2, '2025-01-06 06:17:58', '2025-01-06 06:17:58'),
(114, 57, 2, '2025-01-06 23:10:42', '2025-01-06 23:10:42'),
(115, 57, 2, '2025-01-06 23:14:12', '2025-01-06 23:14:12');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('qMPBpoHhakishVLA723KBfl220sUURQq9HAtgZVu', 1, '192.168.50.71', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoic0JWVG00aXVXYk56VTY5Z29OcU95aFhoTm1JV2pEZFFLc1hwQ3dFRCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjY1OiJodHRwOi8vMTkyLjE2OC41MC43MS9BZmZpbGlhdGVfU3lzdGVtL3B1YmxpYy91c2Vycy9hZmZpbGlhdGVfdXNlciI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1736330911);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subscription_plan_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `stripe_id` varchar(255) NOT NULL,
  `stripe_status` varchar(255) NOT NULL,
  `stripe_price` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `trial_ends_at` timestamp NULL DEFAULT NULL,
  `ends_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `user_id`, `subscription_plan_id`, `type`, `stripe_id`, `stripe_status`, `stripe_price`, `quantity`, `trial_ends_at`, `ends_at`, `created_at`, `updated_at`) VALUES
(9, 10, 2, 'default', 'fergteyt', 'active', 'ytutuiyiou', 1, NULL, '2025-01-27 07:15:29', '2024-12-27 07:15:29', '2024-12-27 07:15:29'),
(10, 11, 3, 'default', 'rtyhsruyji', 'active', 'ytutuiyioui776', 1, NULL, '2025-01-27 07:16:38', '2024-12-27 07:16:38', '2024-12-27 07:16:38'),
(11, 15, 2, 'default', 'fergteyttyu', 'active', 'reyteruytiu', 1, NULL, '2025-01-30 22:17:57', '2024-12-30 22:17:57', '2024-12-30 22:17:57'),
(12, 10, 3, 'default', '12423423', 'active', '100', 1, NULL, '2025-01-31 00:40:10', '2024-12-31 00:40:10', '2024-12-31 00:40:10'),
(13, 40, 2, 'default', '1242342338', 'active', '100', 1, NULL, '2025-01-31 00:45:04', '2024-12-31 00:45:04', '2024-12-31 00:45:04'),
(14, 44, 1, 'default', 'ytutuiyiou', 'active', 'fergteyt', 1, NULL, '2025-01-31 23:41:52', '2024-12-31 23:41:52', '2024-12-31 23:41:52'),
(16, 47, 2, 'default', 'wewqr234', 'active', 'ytutuiyiou', 1, NULL, '2025-02-02 00:01:03', '2025-01-02 00:01:03', '2025-01-02 00:01:03'),
(17, 50, 1, 'default', 'uuiuyiol', 'active', 'reyteruytiu', 1, NULL, '2025-02-02 00:24:35', '2025-01-02 00:24:35', '2025-01-02 00:24:35'),
(18, 53, 2, 'default', 'erty n36234', 'active', 'ytutuiyiou', 1, NULL, '2025-02-02 02:58:33', '2025-01-02 02:58:33', '2025-01-02 02:58:33'),
(19, 54, 1, 'default', 'ytutuiyiou88', 'active', 'ytutuiyiou', 1, NULL, '2025-02-02 03:12:31', '2025-01-02 03:12:31', '2025-01-02 03:12:31'),
(21, 57, 1, 'default', 'fergteyt46', 'active', 'ytutuiyiou', 1, NULL, '2025-02-03 06:15:23', '2025-01-03 06:15:23', '2025-01-03 06:15:23');

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` double NOT NULL DEFAULT 0,
  `coin` int(11) NOT NULL DEFAULT 0,
  `stripe_id` varchar(128) DEFAULT NULL,
  `stripe_price_id` varchar(128) DEFAULT NULL,
  `billing_interval` enum('month','year','once') DEFAULT 'month',
  `ordering` int(11) NOT NULL DEFAULT 0,
  `is_popular` enum('yes','no') NOT NULL DEFAULT 'no',
  `display_status` enum('enable','disable') NOT NULL DEFAULT 'enable',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `name`, `description`, `price`, `coin`, `stripe_id`, `stripe_price_id`, `billing_interval`, `ordering`, `is_popular`, `display_status`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Primary', 'this is primary subscription', 1500, 50, 'rtyuhjtujuy', 'ert5et5e', 'month', 0, 'no', 'enable', 'active', '2024-12-27 04:34:24', '2024-12-27 04:34:24'),
(2, 'Pro', 'this is pro subscription', 2000, 100, 'rtyuhjtujuyerew', 'ert5et5e', 'year', 0, 'no', 'enable', 'active', '2024-12-27 04:35:24', '2024-12-27 04:35:24'),
(3, 'Platinum', 'this is Platinum subscription', 2500, 200, 'rtyuhjtujuyerewertfew', 'efrrt5et5e', 'once', 0, 'no', 'enable', 'active', '2024-12-27 04:36:24', '2024-12-27 04:36:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `activity_status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `activity_status`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'admin', 'admin@gmail.com', '2024-12-27 04:34:24', '$2y$12$7X8PemlJACZCYkfVQ26nV.DnxAniRSAWBay6CmVNmZn4ZvlQvdmpe', 'active', NULL, '2024-12-27 04:34:24', '2024-12-31 01:36:55', NULL),
(2, 'shafa khan', 'shafa@technobd.com', NULL, '$2y$12$wU4joRl8XY5MMqAmoJ8pjeigU6m2PnvtmSUgpP7c/T5lI0lr81ZJ6', 'inactive', NULL, '2024-12-27 04:35:30', '2025-01-06 00:26:00', NULL),
(10, 'test1', 'test1@gmail.com', NULL, '$2y$12$g2.e2jws3LmJo1laCxptM.CpD4QnfchPelUoK4mNtW1IDY0qFg14S', 'inactive', NULL, '2024-12-27 06:23:20', '2025-01-02 04:33:49', '2025-01-02 04:33:49'),
(11, 'test2', 'test2@gmail.com', NULL, '$2y$12$ZSdKN.UTyJzqcQKYMuY7hesOZn4.vX5cDu3mvUi925juwPsWieZXu', 'inactive', NULL, '2024-12-27 06:24:10', '2025-01-02 04:37:22', '2025-01-02 04:37:22'),
(13, 'test3', 'test3@gmail.com', NULL, '$2y$12$xleyRcqYAonpvtExNToiGOjG0MrphnbzhheYPNt..mpCeCH2L8LAq', 'active', NULL, '2024-12-29 23:58:38', '2024-12-29 23:58:38', NULL),
(14, 'test4', 'test4@gmail.com', NULL, '$2y$12$wxf.9jRRgc55vhaJWPFk/.Xbf7h1MySGDzTpBBVQZwVC/XFWy6DDK', 'active', NULL, '2024-12-30 00:55:16', '2024-12-30 00:55:16', NULL),
(15, 'test5', 'test5@gmail.com', NULL, '$2y$12$g9FRGnCFRuMqDPeObxFyJ.8vmFS2AJynDivt2XzQkhOygh2yDyZMq', 'active', NULL, '2024-12-30 00:56:42', '2024-12-30 00:56:42', NULL),
(16, 'test6', 'test6@gmail.com', NULL, '$2y$12$moDmCvFoAkK8dG80WYEyT.Qog4z0i2VN1k9dwqzS5jRhMvFOHCa8.', 'active', NULL, '2024-12-30 00:58:03', '2024-12-30 00:58:03', NULL),
(17, 'test7', 'test7@gmail.com', NULL, '$2y$12$xXf5hE7Ugf.fB5DhhgF56ehgd6xOZVpzjQwWD19y.AhaHu.n4QXKC', 'active', NULL, '2024-12-30 01:00:46', '2024-12-30 01:00:46', NULL),
(18, 'test8', 'test8@gmail.com', NULL, '$2y$12$5I2x4c8BbR9mqGJTaDyLJuFSLRhjupXYpPSz1UcfFjL/c2UVTL0zq', 'active', NULL, '2024-12-30 01:01:32', '2024-12-30 01:01:32', NULL),
(19, 'test9', 'test9@gmail.com', NULL, '$2y$12$Y52048sDiADSsboYdg4ygel6hDw0Qoa5RkHFOzeqmftwuXszmLzei', 'active', NULL, '2024-12-30 01:02:08', '2024-12-30 01:02:08', NULL),
(20, 'test11', 'test11@gmail.com', NULL, '$2y$12$WfHQbZ99Bgkqxfy8NqlkD.FChZCrKfHNHC9Zp5z.Fz5lQ1kqamL.O', 'active', NULL, '2024-12-30 01:04:13', '2024-12-30 01:04:13', NULL),
(21, 'test12', 'test12@gmail.com', NULL, '$2y$12$2Cwnr84uy5uFzg71ty5MzOXipDyaPIBLhpcmJyWrjWDSlF7f2aoe.', 'active', NULL, '2024-12-30 03:23:09', '2024-12-30 03:23:09', NULL),
(22, 'test13', 'test13@gmail.com', NULL, '$2y$12$CVOQHahACL.6Cz5Ivc3URORP6QWJWRrpxi1n8rddQPEWWh.kcNUsO', 'active', NULL, '2024-12-30 03:24:52', '2024-12-30 03:24:52', NULL),
(23, 'test14', 'test14@gmail.com', NULL, '$2y$12$gtV3eQJCFExEz4wIPFVTTe9s0lO6PlOu.2vmcrKWZGzOJO3EQ6dca', 'inactive', NULL, '2024-12-30 03:26:15', '2024-12-30 03:28:59', '2024-12-30 03:28:59'),
(24, 'test15', 'test15@gmail.com', NULL, '$2y$12$hCOEzvXx1JX3/LhTM1Rtg.IrTCo8fWvgqjTLhUoiOw0L083UPeDFW', 'active', NULL, '2024-12-30 03:51:19', '2024-12-30 03:51:19', NULL),
(25, 'test16', 'test165@gmail.com', NULL, '$2y$12$VGTayHfGq0udDRW0Oo4yZe9ninjZX0M9kUMeYfCz0c8VM4Hroq5ye', 'active', NULL, '2024-12-30 03:52:23', '2024-12-30 03:52:23', NULL),
(26, 'test 17', 'test17@gmail.com', NULL, '$2y$12$V6aTYsrqIS5NsCLZNmwxtuhRll0br8XhnMtjZaOP4HMu3YbImirCS', 'active', NULL, '2024-12-30 04:06:39', '2024-12-30 04:06:39', NULL),
(27, 'test19', 'test19@gmail.com', NULL, '$2y$12$pv/bLD7ueu28GAQxY6SNp.XfH9mu4R.8XQQaNMzaiBerD6myxvONa', 'active', NULL, '2024-12-30 04:08:23', '2024-12-30 04:08:23', NULL),
(28, 'test 18', 'test18@gmail.com', NULL, '$2y$12$agLW5IiMSbsPorWI5PJmvuWld8ZyrhO5IenOcM7GC.DuYa3jUST.i', 'active', NULL, '2024-12-30 04:11:55', '2024-12-30 04:11:55', NULL),
(29, 'test20', 'test20@gmail.com', NULL, '$2y$12$BzaWTh02EOZNGM6OAjtedOB2X4CUujSxJH4SVtSf6ZJK/bbfRAALS', 'active', NULL, '2024-12-30 04:21:47', '2024-12-30 04:21:47', NULL),
(30, 'test21', 'test21@gmail.com', NULL, '$2y$12$I5HjBEmAx3XZQ4UcDoCnHOGdT4LstRonEtiw0Ke0Nmgq026Vv9bki', 'active', NULL, '2024-12-30 04:22:51', '2024-12-30 04:22:51', NULL),
(31, 'test22', 'test22@gmail.com', NULL, '$2y$12$5sdsFJtImY8nAU3/LFNJ4OblRgRDOLEwBk1K3kPt4MtL/tThs2l6O', 'active', NULL, '2024-12-30 04:26:51', '2024-12-30 04:26:51', NULL),
(32, 'test23', 'test23@gmail.com', NULL, '$2y$12$Qtsyj/kC3NEqTUXzx9AG/emaAWTZLOyGRMgLXzS8dxMqaQWnIcH3.', 'active', NULL, '2024-12-30 04:28:24', '2024-12-30 04:28:24', NULL),
(33, 'test24', 'test24@gmil.com', NULL, '$2y$12$KLa3QZrIPADz8Sie8kl.g.5.ZnyGNACsnSrpdbLFqdQhg46o2Inzu', 'active', NULL, '2024-12-30 04:29:29', '2024-12-30 04:29:29', NULL),
(34, 'test 26', 'test26@gmail.com', NULL, '$2y$12$0zURM6xNhy.wzA2c1szlKeBztIhnUNkEPcXOkNLcKTXyJhA9Lv7sm', 'active', NULL, '2024-12-30 04:30:55', '2024-12-30 04:30:55', NULL),
(35, 'test 27', 'test27@gmail.com', NULL, '$2y$12$WPn/k4G1QtcoML1178EnV.Keu85dPCRa5PYD2ooEUPzMojIRXPW9.', 'active', NULL, '2024-12-30 04:38:10', '2024-12-30 04:38:10', NULL),
(36, 'test 28', 'test28@gmail.com', NULL, '$2y$12$dCgoVMBeH9zl1yCtBuErt.sEjsFXGZtOzPaYkjbc9p5o4EbpcsLIK', 'active', NULL, '2024-12-30 04:40:11', '2024-12-30 04:40:11', NULL),
(37, 'test29', 'test29@gmail.com', NULL, '$2y$12$3wr.lRWkNtGJOvd.4U1CJ.cRrdAHtDQIYtIMxTE/g7c.1y7hzWzjm', 'active', NULL, '2024-12-30 04:41:13', '2024-12-30 04:41:13', NULL),
(38, 'test 31', 'test31@gmail.com', NULL, '$2y$12$x248w/GPPgm0N8pRNFFiL.2OnavqgVTosN8aniaO7zIjaRpT1cQve', 'active', NULL, '2024-12-30 04:44:41', '2024-12-30 04:44:41', NULL),
(39, 'test 33', 'test33@gmail.com', NULL, '$2y$12$HUdq8rDpu1bz0.beNJPkFOVR/TDKXUeXpT8DXrs2MyGH27JQGKJra', 'active', NULL, '2024-12-30 04:46:19', '2024-12-30 04:46:19', NULL),
(40, 'Demo User 2', 'demo88@xyz.com', NULL, '$2y$12$QR5WUBuSQc8iaKlIDpeileWyZH4W6JxxRkOpJw.vMXVtfDaE1QEOe', 'active', NULL, '2024-12-31 00:43:16', '2024-12-31 00:43:16', NULL),
(42, 'demo3', 'demo3@gmail.com', NULL, '$2y$12$Y9YQOPlJSBmaUQfh61FXQe8nwRwQo2fzXK91fqWVKXoB94lzo4Ozu', 'active', NULL, '2024-12-31 03:18:52', '2024-12-31 03:18:52', NULL),
(43, 'super user', 'superuser@gmail.com', NULL, '$2y$12$3pCjFbWhXWMRjD/Xp0Nif.k/mGr3QSMiDHgkA8QgxF4TxWv9JU9f6', 'active', NULL, '2024-12-31 22:36:33', '2024-12-31 22:36:33', NULL),
(44, 'test34', 'test34@gmail.com', NULL, '$2y$12$PInzwjnGMG/mJt4MOYgvUeS7cUncUWMRWmqK9ivfZ0w6ADt4K24fG', 'active', NULL, '2024-12-31 22:48:42', '2024-12-31 22:48:42', NULL),
(45, 'test 35', 'test35@gmail.com', NULL, '$2y$12$7t5hNzbfk8zAlZs/.VsmYe7XgV64RRcagQ8bqaAoAAOjclXe5XfdS', 'active', NULL, '2024-12-31 22:50:01', '2024-12-31 22:50:01', NULL),
(46, 'test36', 'test36@gmail.com', NULL, '$2y$12$ZfGM1/hSbpt4K82h6rRhueoL4iE/uVOynmNQBhZR0pZuMxsGI04ty', 'inactive', NULL, '2025-01-01 00:33:26', '2025-01-01 23:33:07', '2025-01-01 23:33:07'),
(47, 'test37', 'test37@gmail.com', NULL, '$2y$12$FyD6xFU.y.qcuk0QzfMexuWYxJASF/oNzceNSLF/OCcCg.y2k1bnK', 'active', NULL, '2025-01-01 23:48:20', '2025-01-01 23:48:20', NULL),
(48, 'test38', 'test38@gmail.com', NULL, '$2y$12$tp0qoXTVQwp8YOkF2tfumOxFTzkzvCWNVYikgf87CQpDR9RHgECjK', 'active', NULL, '2025-01-02 00:06:49', '2025-01-02 00:06:49', NULL),
(49, 'test39', 'test39@gmail.com', NULL, '$2y$12$q7TrpWxouHevro6iVaMceeIim5KzmbAX3qrZanNQJZgWB/XiO3py.', 'active', NULL, '2025-01-02 00:22:09', '2025-01-02 00:22:09', NULL),
(50, 'test40', 'test40@gmail.com', NULL, '$2y$12$HylNvSJGbMN0W//RlYJ73OuytHd6jS0evGyPg/GaW/.ItDThdXeBq', 'active', NULL, '2025-01-02 00:24:03', '2025-01-02 00:24:03', NULL),
(51, 'test41', 'test41@gmail.com', NULL, '$2y$12$K63HcB1Lxh4idqEoZkHKq.asnwL9NZodUk2sxXsPgHTu9Npowzmjm', 'active', NULL, '2025-01-02 02:55:56', '2025-01-02 02:55:56', NULL),
(52, 'test42', 'test42@gmail.com', NULL, '$2y$12$a9xFjA/57ek/MwhkTzdq0.ozNN771co.12P7FFRmpwTX6f9CQQ6/S', 'active', NULL, '2025-01-02 02:57:02', '2025-01-02 02:57:02', NULL),
(53, 'test43', 'test43@gmail.com', NULL, '$2y$12$17H8s3EWiH7CGMLVD9X8CurtvT9z0VWRaAKIeYKquNEbQkWzEQTgu', 'active', NULL, '2025-01-02 02:57:48', '2025-01-02 02:57:48', NULL),
(54, 'test44', 'test44@gmail.com', NULL, '$2y$12$TcQ4fD.SQdqnYJezweaQtezQphgrp/r8d8jyR5C6VXQdaXyhIBq8u', 'active', NULL, '2025-01-02 03:12:12', '2025-01-02 03:12:12', NULL),
(55, 'test 45', 'test45@gmail.com', NULL, '$2y$12$nliOrSfFxZFx3sfk8SxFvOvpAsEbhYZSm/RRWIhO/aUJZL/wP5pmC', 'active', NULL, '2025-01-02 03:22:22', '2025-01-02 03:22:22', NULL),
(56, 'test46', 'test46@gmail.com', NULL, '$2y$12$k1YhgNAyncyxr.T4yvtm2uweSDETpOExxpvtMm.KZNWenKxNkgdGa', 'active', NULL, '2025-01-02 06:29:05', '2025-01-02 06:29:05', NULL),
(57, 'test47', 'test47@gmail.com', NULL, '$2y$12$lv0d2F3K3AIC6ZB7PNvJhel9Mh0K69j0PmhtjY70kU5uMXG/OlKVy', 'active', NULL, '2025-01-03 06:13:51', '2025-01-03 06:13:51', NULL),
(59, 'test 48', 'test48@gmail.com', NULL, '$2y$12$XTxbZG2Hp.Zw4YhtjHjtwe5F7oEW5VdBG1izEAa8OaTh79XmzbKOG', 'inactive', NULL, '2025-01-06 02:09:13', '2025-01-06 05:45:07', '2025-01-06 05:45:07'),
(61, 'test p', 'testp@gmail.com', NULL, '$2y$12$MYkgj/NgjFf3uDjAJqz8AuZgqIWooP3M2YyHMoCz3QoL3uH..dqNO', 'inactive', NULL, '2025-01-06 04:06:57', '2025-01-06 04:07:33', '2025-01-06 04:07:33'),
(62, 'test 49', 'test49@gmail.com', NULL, '$2y$12$iUq1c78K0W0cV7Y.iySC0.N6OabS7Adz7q4XLGzsaSyhJ3snKA0w6', 'active', NULL, '2025-01-06 04:18:20', '2025-01-06 04:18:20', NULL),
(63, 'test 50', 'test50@gmail.com', NULL, '$2y$12$W1UGqYDe7L9EagMBgBoDVOI7MKZ1/FAeVnzTif5GjNB7tqDWnkZKy', 'active', NULL, '2025-01-06 04:21:20', '2025-01-06 04:21:20', NULL),
(64, 'test 51', 'test51@gmail.com', NULL, '$2y$12$BbdQDumZDM8sd1w3CJNMvOCAtmcvJYXqFnaafSuK7fUKtmwB.wNsi', 'active', NULL, '2025-01-06 04:37:11', '2025-01-06 04:37:11', NULL),
(65, 'test52', 'test52@gmail.com', NULL, '$2y$12$kx2ixagKXAb9T59BDb0GSeo/AtAA7UZt9gwzEtWp.oVH84q3NGjSu', 'active', NULL, '2025-01-06 04:40:47', '2025-01-06 05:46:58', NULL),
(66, 'test53', 'test53@gmail.com', NULL, '$2y$12$dJevPGFJixq/HHOlCh3.zeABQNenDWrkBlmpuWmsHwaNfqndgCFny', 'active', NULL, '2025-01-06 05:22:39', '2025-01-06 05:22:39', NULL),
(67, 'admin2', 'admin2@gmail.com', NULL, '$2y$12$A9cvn0LPloCcjnbPHh7ckeVJVUd6f/hXzPqMNSNPDFx7WXdJGE1PW', 'inactive', NULL, '2025-01-06 05:23:52', '2025-01-06 06:16:48', '2025-01-06 06:16:48'),
(68, 'affiliate2', 'affiliate2@gmail.com', NULL, '$2y$12$1ZpnsumR972uFCh2dYnv9.W56W5/O43jfDdfs9obLdZcRtuEYIuRS', 'active', NULL, '2025-01-06 05:26:11', '2025-01-06 05:26:11', NULL),
(69, 'test54', 'test54@gmail.com', NULL, '$2y$12$Ku/nG1nBgZtnEmxDAKqmz.1HSFkOXShXCO1aWnuu9V6OrT1D.bYSa', 'active', NULL, '2025-01-06 06:13:48', '2025-01-06 06:13:48', NULL),
(70, 'admin3', 'admin3@gmail.com', NULL, '$2y$12$2lRyaDtAOm1GpPQ4Ig0LjezRzXbrbZUj.18If/F9KxrWFdf3.TByu', 'inactive', NULL, '2025-01-06 06:14:13', '2025-01-06 06:16:45', '2025-01-06 06:16:45'),
(71, 'admin4', 'admin4@gmail.com', NULL, '$2y$12$vhV1RAlG62UurUHiCYkzv.RzlBozIG/fCRVdww0piPgSDUBva8/IC', 'inactive', NULL, '2025-01-06 06:15:07', '2025-01-06 06:16:41', '2025-01-06 06:16:41'),
(72, 'test 55', 'test55@gmail.com', NULL, '$2y$12$vuBRK2yRrnoLjwqAEHYjXuREaFkZt014P768ZW/VHoNEaG86xTuiC', 'active', NULL, '2025-01-06 06:17:58', '2025-01-06 06:17:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `address` text DEFAULT NULL,
  `acc_name` varchar(255) DEFAULT NULL,
  `acc_no` varchar(34) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_address` text DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `percentage_value` decimal(5,2) DEFAULT NULL,
  `status` enum('pending','approved','rejected','Deleted','just_created') NOT NULL DEFAULT 'just_created',
  `affiliate_code` varchar(255) DEFAULT NULL,
  `affiliate_status` enum('enable','disable') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `user_id`, `address`, `acc_name`, `acc_no`, `bank_name`, `branch_address`, `phone_number`, `percentage_value`, `status`, `affiliate_code`, `affiliate_status`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, NULL, '2024-12-27 04:34:25', '2025-01-01 23:40:32'),
(2, 2, 'dhaka mirpur', 'shafa', '1234325', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', '67PCYKG6Z7', 'enable', '2024-12-27 04:35:30', '2025-01-06 22:20:00'),
(10, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-27 06:23:20', '2024-12-29 23:49:20'),
(11, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-27 06:24:10', '2024-12-27 06:24:10'),
(13, 13, 'chuadanga', 'test 3', '567658769', 'trust bank', 'chuadanga', '01788997766', 10.00, 'approved', 'K9TWBOJVWA', 'enable', '2024-12-29 23:58:38', '2024-12-31 01:49:49'),
(14, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 00:55:16', '2024-12-30 00:55:16'),
(15, 15, 'jessore', 'test 5', '345234646', 'trust bank', 'jessore', '01960951628', 10.00, 'approved', 'NMOZXBQH44', 'enable', '2024-12-30 00:56:42', '2025-01-06 05:40:53'),
(16, 16, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, NULL, '2024-12-30 00:58:04', '2025-01-01 23:29:45'),
(17, 17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 01:00:46', '2024-12-30 01:00:46'),
(18, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 01:01:32', '2024-12-30 01:01:32'),
(19, 19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 01:02:08', '2024-12-30 01:02:08'),
(20, 20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 01:04:13', '2024-12-30 01:04:13'),
(21, 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 03:23:09', '2024-12-30 03:23:09'),
(22, 22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 03:24:52', '2024-12-30 03:24:52'),
(23, 23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 03:26:15', '2024-12-30 03:26:15'),
(24, 24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 03:51:19', '2024-12-30 03:51:19'),
(25, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 03:52:23', '2024-12-30 03:52:23'),
(26, 26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:06:39', '2024-12-30 04:06:39'),
(27, 27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:08:23', '2024-12-30 04:08:23'),
(28, 28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:11:55', '2024-12-30 04:11:55'),
(29, 29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:21:47', '2024-12-30 04:21:47'),
(30, 30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:22:51', '2024-12-30 04:22:51'),
(31, 31, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:26:51', '2024-12-30 04:26:51'),
(32, 32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:28:24', '2024-12-30 04:28:24'),
(33, 33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:29:29', '2024-12-30 04:29:29'),
(34, 34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:30:55', '2024-12-30 04:30:55'),
(35, 35, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, NULL, '2024-12-30 04:38:10', '2025-01-01 23:56:34'),
(36, 36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:40:11', '2024-12-30 04:40:11'),
(37, 37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:41:13', '2024-12-30 04:41:13'),
(38, 38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:44:41', '2024-12-30 04:44:41'),
(39, 39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2024-12-30 04:46:19', '2024-12-30 04:46:19'),
(40, 40, '46 Kazi Nazrul Islam Avenue (4th Floor) Karwan Baz', 'Demo User', '123232', 'ABC Bank', '46 Kazi Nazrul Islam Avenue (4th Floor) Karwan Baz', '03535434', 30.00, 'approved', 'EX7EBKBZ65', 'enable', '2024-12-31 00:43:16', '2025-01-06 00:54:51'),
(42, 42, 'dhaka mirpur', 'demo 3 bank', '123412432', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 11.00, 'approved', 'CIH2XQWQZW', 'enable', '2024-12-31 03:18:52', '2025-01-06 00:54:54'),
(43, 43, 'kawranbazar', 'super user account', '132214325657', 'dutch bangla bank', '46 Kazi Nazrul Islam Avenue (4th Floor) Karwan Bazar, Dhaka - 1215, Bangladesh.', '01960951628', 15.00, 'approved', 'RANS2YECVG', 'enable', '2024-12-31 22:36:33', '2025-01-06 01:01:05'),
(44, 44, 'chuadanga', 'test 34 user', '5645132398', 'brac bank', 'chuadanga', '01960951628', NULL, 'rejected', NULL, NULL, '2024-12-31 22:48:42', '2025-01-02 01:22:37'),
(45, 45, 'chuadanga', 'test 35 user', '43645768987976', 'trust bank', 'chuadanga', '01960951628', NULL, 'rejected', NULL, NULL, '2024-12-31 22:50:01', '2025-01-02 00:58:50'),
(46, 46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-01 00:33:26', '2025-01-01 00:33:26'),
(47, 47, 'jessore', '09394320432', '4325346', 'trust bank', 'jessore', '01960951628', 13.00, 'just_created', NULL, NULL, '2025-01-01 23:48:20', '2025-01-02 01:00:03'),
(48, 48, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-02 00:06:49', '2025-01-02 00:06:49'),
(49, 49, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, NULL, '2025-01-02 00:22:09', '2025-01-02 03:27:13'),
(50, 50, 'dhaka mirpur', 'test40 user', '346547657', 'trust bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', '5VHFYRWIRY', 'enable', '2025-01-02 00:24:03', '2025-01-06 05:35:04'),
(51, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-02 02:55:56', '2025-01-02 02:55:56'),
(52, 52, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-02 02:57:02', '2025-01-02 02:57:02'),
(53, 53, 'kawranbazar', 'test43', '43534656788', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'TVUQFBZ13L', 'enable', '2025-01-02 02:57:48', '2025-01-06 04:45:41'),
(54, 54, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, 'disable', '2025-01-02 03:12:12', '2025-01-06 04:46:02'),
(55, 55, 'dhaka mirpur', 'test 45 user', '65478', 'trust bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'FNGBZUPMC8', 'enable', '2025-01-02 03:22:22', '2025-01-06 23:07:20'),
(56, 56, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-02 06:29:05', '2025-01-02 06:29:05'),
(57, 57, 'uttara-sector-07', 'test 47 user', '21432542355', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'M1FXLJNVIZ', 'enable', '2025-01-03 06:13:51', '2025-01-06 23:14:12'),
(58, 59, 'dhaka mirpur', 'test 48', '322132', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', '83C733GJGQ', NULL, '2025-01-06 02:09:13', '2025-01-06 02:09:13'),
(60, 61, 'chuadanga', 'testp', '43543543', 'dutch bangla bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'ALY6DGUTZE', 'enable', '2025-01-06 04:06:57', '2025-01-06 04:06:57'),
(61, 62, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-06 04:18:20', '2025-01-06 04:18:20'),
(62, 63, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-06 04:21:20', '2025-01-06 04:21:20'),
(63, 64, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-06 04:37:11', '2025-01-06 04:37:11'),
(64, 65, 'fdg', 'shafa', '34534', '56', '4', '01960951628', 10.00, 'approved', '2ADLI2YR0U', 'enable', '2025-01-06 04:40:47', '2025-01-06 23:06:51'),
(65, 66, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, 'enable', '2025-01-06 05:22:39', '2025-01-06 06:02:13'),
(66, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-06 05:23:52', '2025-01-06 05:23:52'),
(67, 68, 'chuadanga', 'affiliate2', '5646578', 'trust bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', '2ENOPQG32L', 'enable', '2025-01-06 05:26:11', '2025-01-06 23:04:47'),
(68, 69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'just_created', NULL, NULL, '2025-01-06 06:13:48', '2025-01-06 06:13:48'),
(69, 70, NULL, NULL, NULL, NULL, NULL, NULL, 10.00, 'just_created', NULL, 'disable', '2025-01-06 06:14:13', '2025-01-06 06:14:39'),
(70, 71, 'gfretret', 'testp', '3453463', '3465365', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'S1UYLLYZFB', 'enable', '2025-01-06 06:15:07', '2025-01-06 06:16:32'),
(71, 72, 'dhaka mirpur', 'test 55 user', '543543', 'trust bank', 'dhaka mirpur', '01960951628', 10.00, 'approved', 'GYXTSD2M84', 'enable', '2025-01-06 06:17:58', '2025-01-06 22:18:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `affiliate_referrals`
--
ALTER TABLE `affiliate_referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `affiliate_referrals_referrer_id_foreign` (`referrer_id`),
  ADD KEY `affiliate_referrals_user_id_foreign` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `commissions`
--
ALTER TABLE `commissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payouts`
--
ALTER TABLE `payouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payouts_affiliate_user_id_foreign` (`affiliate_user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscriptions_stripe_id_unique` (`stripe_id`),
  ADD KEY `subscriptions_user_id_stripe_status_index` (`user_id`,`stripe_status`),
  ADD KEY `subscriptions_user_id_index` (`user_id`),
  ADD KEY `subscriptions_subscription_plan_id_index` (`subscription_plan_id`),
  ADD KEY `subscriptions_stripe_status_index` (`stripe_status`),
  ADD KEY `subscriptions_trial_ends_at_index` (`trial_ends_at`),
  ADD KEY `subscriptions_ends_at_index` (`ends_at`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscription_plans_price_index` (`price`),
  ADD KEY `subscription_plans_coin_index` (`coin`),
  ADD KEY `subscription_plans_stripe_id_index` (`stripe_id`),
  ADD KEY `subscription_plans_stripe_price_id_index` (`stripe_price_id`),
  ADD KEY `subscription_plans_billing_interval_index` (`billing_interval`),
  ADD KEY `subscription_plans_ordering_index` (`ordering`),
  ADD KEY `subscription_plans_is_popular_index` (`is_popular`),
  ADD KEY `subscription_plans_display_status_index` (`display_status`),
  ADD KEY `subscription_plans_status_index` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_details_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `affiliate_referrals`
--
ALTER TABLE `affiliate_referrals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `commissions`
--
ALTER TABLE `commissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `payouts`
--
ALTER TABLE `payouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `affiliate_referrals`
--
ALTER TABLE `affiliate_referrals`
  ADD CONSTRAINT `affiliate_referrals_referrer_id_foreign` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `affiliate_referrals_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payouts`
--
ALTER TABLE `payouts`
  ADD CONSTRAINT `payouts_affiliate_user_id_foreign` FOREIGN KEY (`affiliate_user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_details`
--
ALTER TABLE `user_details`
  ADD CONSTRAINT `user_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
